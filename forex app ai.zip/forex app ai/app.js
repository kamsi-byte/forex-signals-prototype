/* ---------- CONFIG (replace placeholders) ---------- */
const TWELVE_KEY = "7aa3c6701e2143ca91f107402a073ab4";       // <-- paste your Twelve Data API key here
const TELEGRAM_TOKEN = "8234976520:AAHIS070XppR_msUmspc_zWM-jWo86iJrvY";       // <-- paste your Telegram bot token (or use server-side proxy)
const TELEGRAM_CHAT_ID = "69996313098";    // <-- paste your Telegram chat id

/* ---------- PAIRS (6 pairs optimized) ---------- */
const PAIRS = ["EUR/USD","GBP/USD","USD/JPY","AUD/USD","USD/CAD","USD/CHF"];

/* ---------- TIMING: keep under Twelve Data free limits ---------- */
// Free limits: 8 credits/minute, 800 credits/day
// With 6 pairs, polling every 11 minutes -> approx (1440/11)*6 ≈ 786 requests/day (<800)
const POLL_INTERVAL_MINUTES = 11;
const POLL_INTERVAL_MS = POLL_INTERVAL_MINUTES * 60 * 1000;

/* ---------- UI elements ---------- */
const loginPanel = document.getElementById("loginPanel");
const appPanel = document.getElementById("appPanel");
const loginBtn = document.getElementById("loginBtn");
const demoBtn = document.getElementById("demoBtn");
const loginMsg = document.getElementById("loginMsg");
const statusEl = document.getElementById("status");
const signalsGrid = document.getElementById("signalsGrid");
const pairSelect = document.getElementById("pairSelect");
const refreshBtn = document.getElementById("refreshBtn");
const sendBtn = document.getElementById("sendBtn");
const acctBalanceEl = document.getElementById("acctBalance");
const riskPctEl = document.getElementById("riskPct");
const autoThresholdEl = document.getElementById("autoThreshold");

/* ---------- Fill pair select ---------- */
PAIRS.forEach(p=>{
  const opt = document.createElement("option");
  opt.value = p; opt.text = p; opt.selected = true;
  pairSelect.appendChild(opt);
});

/* ---------- simple auth ---------- */
const VALID_USER = "kc trades", VALID_PASS = "376148";
loginBtn.addEventListener("click", () => {
  const u = document.getElementById("username").value.trim();
  const p = document.getElementById("password").value.trim();
  if(u === VALID_USER && p === VALID_PASS){
    loginPanel.classList.add("hidden");
    appPanel.classList.remove("hidden");
    loginMsg.innerText = "";
    start();
  } else {
    loginMsg.innerText = "Incorrect username or password";
  }
});
demoBtn.addEventListener("click", ()=>{
  document.getElementById("username").value = VALID_USER;
  document.getElementById("password").value = VALID_PASS;
  loginBtn.click();
});

/* ---------- Helper: Twelve Data time_series fetch ---------- */
async function fetchCandles(pair){
  // Twelve Data expects symbols like "EUR/USD" as "EUR/USD" or "EURUSD" depending on endpoint.
  // Use time_series endpoint and symbol escaping
  const symbol = encodeURIComponent(pair);
  const url = `https://api.twelvedata.com/time_series?symbol=${symbol}&interval=1min&outputsize=100&format=json&apikey=${TWELVE_KEY}`;
  try {
    const r = await fetch(url);
    const j = await r.json();
    // Twelve Data returns status 'error' in json if fails
    if(j.status === 'error' || !j.values || j.values.length === 0) return null;
    // values array: newest first - convert to oldest-first numeric arrays
    const values = j.values.slice().reverse();
    // map to OHLC objects
    return values.map(v=>({
      datetime: v.datetime,
      open: parseFloat(v.open),
      high: parseFloat(v.high),
      low: parseFloat(v.low),
      close: parseFloat(v.close)
    }));
  } catch(e){
    console.error("fetchCandles error", e);
    return null;
  }
}

/* ---------- Indicator functions ---------- */
function emaArray(values, period){
  if(values.length === 0) return [];
  const out = [];
  const alpha = 2/(period+1);
  let prev = values[0];
  out.push(prev);
  for(let i=1;i<values.length;i++){
    prev = alpha*values[i] + (1-alpha)*prev;
    out.push(prev);
  }
  return out;
}
function computeRSI(closes, period=14){
  if(closes.length < period+1) return null;
  let gains=0, losses=0;
  for(let i=closes.length-period;i<closes.length;i++){
    const d = closes[i] - closes[i-1];
    if(d>0) gains += d; else losses += Math.abs(d);
  }
  const avgGain = gains/period, avgLoss = losses/period;
  const rs = avgGain / (avgLoss || 1e-9);
  return +(100 - (100/(1+rs))).toFixed(2);
}
function computeATR(ohlc, period=14){
  if(ohlc.length < period+1) return null;
  const trs = [];
  for(let i=1;i<ohlc.length;i++){
    const H = ohlc[i].high, L = ohlc[i].low, PC = ohlc[i-1].close;
    trs.push(Math.max(H-L, Math.abs(H-PC), Math.abs(L-PC)));
  }
  const slice = trs.slice(-period);
  const atr = slice.reduce((s,v)=>s+v,0)/period;
  return +atr.toFixed(6);
}
function computeMACDHist(closes){
  if(closes.length < 26) return null;
  const ema12 = emaArray(closes,12);
  const ema26 = emaArray(closes,26);
  const macd = ema12.map((v,i)=> v - (ema26[i] || v));
  const signal = emaArray(macd.slice(-9),9).slice(-1)[0] || 0;
  const hist = macd[macd.length-1] - signal;
  return +hist.toFixed(6);
}

/* ---------- Fibonacci utilities (Option 2 logic simplified) ---------- */
function findSwingHighLow(ohlc, lookback=50){
  // find highest high and lowest low in lookback
  const slice = ohlc.slice(-lookback);
  let high = -Infinity, low = Infinity, hiIdx=0, loIdx=0;
  slice.forEach((c,i)=>{
    if(c.high > high){ high = c.high; hiIdx = i; }
    if(c.low < low){ low = c.low; loIdx = i; }
  });
  return { high, low, hiIdx, loIdx, slice };
}
function fibLevels(high, low){
  const diff = high - low;
  return {
    "0.0": high,
    "0.236": high - 0.236*diff,
    "0.382": high - 0.382*diff,
    "0.5": high - 0.5*diff,
    "0.618": high - 0.618*diff,
    "0.705": high - 0.705*diff,
    "0.786": high - 0.786*diff,
    "1.0": low,
    ext127: high + 0.272*diff,
    ext1618: high + 0.618*diff,
    ext2: high + diff
  };
}

/* ---------- Smart TP/SL & position sizing ---------- */
function computeTP_SL(price, action, ohlc){
  const atr = computeATR(ohlc,14) || (price*0.001);
  const rr = 2.0;
  let sl, tp;
  if(action === "BUY"){
    sl = +(price - Math.max(atr*1.5, price*0.002)).toFixed(6);
    tp = +(price + (price - sl)*rr).toFixed(6);
  } else {
    sl = +(price + Math.max(atr*1.5, price*0.002)).toFixed(6);
    tp = +(price - (sl - price)*rr).toFixed(6);
  }
  return { tp, sl, atr };
}
function positionSize(accountUsd, riskPercent, price, sl){
  const riskUsd = accountUsd * (riskPercent/100);
  const pipSize = price > 100 ? 0.01 : 0.0001; // JPY vs others
  const pipDist = Math.abs(price - sl);
  const pipDistPips = pipDist / pipSize;
  const pipValuePerLot = (pipSize * 100000) / price;
  const riskPerLot = pipDistPips * pipValuePerLot;
  if(riskPerLot <= 0) return 0;
  const lots = riskUsd / riskPerLot;
  return Math.max(0, +lots.toFixed(2));
}

/* ---------- AI Market Analyst (scoring & explanation) ---------- */
function aiAnalyst(context){
  // context contains booleans / numbers from indicators
  // Weighted scoring that mimics an "AI" expert system
  let score = 0;
  const reasons = [];
  if(context.trend === "UP") { score += 20; reasons.push("Trend UP"); }
  if(context.trend === "DOWN") { score += 20; reasons.push("Trend DOWN"); }
  if(context.emaConfluence) { score += 15; reasons.push("EMA confluence"); }
  if(context.rsi && context.rsi > 40 && context.rsi < 70) { score += 10; reasons.push("RSI in favorable zone"); }
  if(context.macd && context.macd > 0) { score += 10; reasons.push("MACD positive"); }
  if(context.fibMatch) { score += 20; reasons.push("Fib confluence"); }
  if(context.atr && context.atr > 0) { score += 5; }
  // normalize to 100
  const probability = Math.min(99, Math.round(score));
  return { probability, reasons: reasons.join("; ") || "Indicators inconclusive" };
}

/* ---------- Render UI signal card ---------- */
function renderSignalCard(obj){
  const div = document.createElement("div");
  div.className = "signal card signal";
  div.innerHTML = `
    <div class="sig-title">
      <div class="sig-pair">${obj.pair}</div>
      <div class="sig-prob">${obj.probability || "N/A"}%</div>
    </div>
    <div>Action: <b>${obj.action || "N/A"}</b></div>
    <div>Price: ${obj.price !== null ? obj.price.toFixed(6) : "N/A"}</div>
    <div>TP: ${obj.tp || "N/A"} | SL: ${obj.sl || "N/A"}</div>
    <div>Lots: ${obj.lots || "N/A"}</div>
    <div class="muted small">Reasons: ${obj.reason || "N/A"}</div>
  `;
  return div;
}

/* ---------- Main process: fetch pairs and analyze ---------- */
async function analyzePair(pair){
  const candles = await fetchCandles(pair);
  if(!candles || candles.length === 0) return { pair, noData: true };

  const closes = candles.map(c=>c.close);
  const last = candles[candles.length-1].close;
  // Indicators
  const ema50 = emaArray(closes,50).slice(-1)[0] || closes[closes.length-1];
  const ema200 = emaArray(closes,200).slice(-1)[0] || closes[closes.length-1];
  const trend = ema50 > ema200 ? "UP" : ema50 < ema200 ? "DOWN":"FLAT";
  const emaConfluence = Math.abs((ema50 - ema200)/ema200) < 0.02; // 2% confluence threshold
  const rsi = computeRSI(closes,14);
  const macd = computeMACDHist(closes);
  const atr = computeATR(candles,14);
  // Fibonacci
  const swing = findSwingHighLow(candles, 100);
  const fib = fibLevels(swing.high, swing.low);
  // Check if last price is near a fib retracement (within small band)
  const nearFib = Object.keys(fib).find(k=>{
    if(k.startsWith("ext")) return false;
    return Math.abs(last - fib[k]) / last < 0.0015; // within 0.15%
  });
  const fibMatch = !!nearFib;

  // Decide action
  let action = null;
  if(trend === "UP" && (rsi && rsi > 40)) action = "BUY";
  else if(trend === "DOWN" && (rsi && rsi < 60)) action = "SELL";
  else action = null;

  // Compute TP/SL and position size
  const { tp, sl } = action ? computeTP_SL(last, action, candles) : { tp:null, sl:null };
  const account = Number(acctBalanceEl.value || 1000);
  const lots = (tp && sl) ? positionSize(account, Number(riskPctEl.value || 1), last, sl) : 0;

  // AI analyst score
  const ctx = { trend: trend==="UP"?"UP":trend==="DOWN"?"DOWN":"FLAT", emaConfluence, rsi, macd, fibMatch, atr };
  const ai = aiAnalyst(ctx);

  // Compose reason
  const reason = ai.reasons + (nearFib ? `; Near Fib ${nearFib}` : "");

  return {
    pair,
    price: last,
    action,
    tp,
    sl,
    atr,
    lots,
    probability: ai.probability,
    reason,
    usedIndicators: ["EMA50","EMA200","RSI","MACD","ATR"].join(", ")
  };
}

/* ---------- Polling loop ---------- */
let pollingTimer = null;
async function performFullRefresh(){
  statusEl.innerText = `Status: fetching ${PAIRS.length} pairs...`;
  signalsGrid.innerHTML = "";
  const selectedPairs = Array.from(pairSelect.selectedOptions).map(o=>o.value);
  // analyze each selected pair sequentially (TwelveData allows up to 8/min; we're calling 6 each 11 minutes)
  for(const p of selectedPairs){
    try {
      const res = await analyzePair(p);
      if(res.noData){
        const noDiv = document.createElement("div");
        noDiv.className="signal card signal";
        noDiv.innerHTML = `<div class="sig-pair">${p}</div><div class="muted">NO DATA AVAILABLE</div>`;
        signalsGrid.appendChild(noDiv);
      } else {
        const card = renderSignalCard(res);
        signalsGrid.appendChild(card);
      }
      // small sleep between calls to avoid any burst (not strictly necessary)
      await new Promise(r=>setTimeout(r, 400));
    } catch(e){
      console.error("Error analyzing", p, e);
    }
  }
  statusEl.innerText = `Status: last update ${new Date().toLocaleString()}`;
}

/* ---------- Auto schedule based on POLL_INTERVAL_MINUTES ---------- */
function start(){
  performFullRefresh();
  if(pollingTimer) clearInterval(pollingTimer);
  pollingTimer = setInterval(performFullRefresh, POLL_INTERVAL_MS);
}

/* ---------- Buttons ---------- */
refreshBtn.addEventListener("click", async ()=>{
  // NOTE: manual refresh uses same cadence — do not spam
  await performFullRefresh();
});
sendBtn.addEventListener("click", async ()=>{
  const cards = Array.from(signalsGrid.querySelectorAll(".signal"));
  if(cards.length === 0){ alert("No signals"); return; }
  // Compile top signals (prob >= threshold)
  const threshold = Number(autoThresholdEl.value || 70);
  const messages = [];
  for(const card of cards){
    const pair = card.querySelector(".sig-pair")?.innerText || "";
    const prob = parseInt(card.querySelector(".sig-prob")?.innerText) || 0;
    if(prob >= threshold){
      const lines = Array.from(card.querySelectorAll("div")).map(d=>d.innerText).join("\n");
      messages.push(lines);
    }
  }
  if(messages.length === 0){ alert("No signals meet threshold"); return; }
  // Combined message
  const full = messages.join("\n\n---\n\n");
  // Send to Telegram (quick single request). IMPORTANT: putting token client-side is insecure.
  if(TELEGRAM_TOKEN.includes("*")) {
    alert("Telegram token placeholder not replaced. Replace *TOKEN* and *chatid* in app.js");
    return;
  }
  try {
    await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: full, parse_mode:"Markdown" })
    });
    alert("Sent to Telegram");
  } catch(e){
    console.error("Telegram send error", e); alert("Telegram send failed");
  }
});

/* ---------- On load: show login panel; appPanel hidden initially ---------- */
appPanel.classList.add("hidden");
// show small instruction
statusEl.innerText = "Status: ready to login";
